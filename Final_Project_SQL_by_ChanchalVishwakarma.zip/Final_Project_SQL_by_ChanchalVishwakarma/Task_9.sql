/* Task 9. Finding Top 5 Customers by Sales Volume.
Walmart wants to reward its top 5 customers who have generated the most sales Revenue. */

SELECT 
	`Customer ID`,
    round(SUM(Total), 2) as total_revenue
FROM walmartsales_dataset
group by `Customer ID`
order by total_revenue DESC
LIMIT 5;

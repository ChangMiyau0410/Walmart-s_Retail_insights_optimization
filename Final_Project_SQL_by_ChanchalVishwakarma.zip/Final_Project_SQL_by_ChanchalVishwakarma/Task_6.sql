/* Task 6. Monthly Sales Distribution by Gender
Walmart wants to understand the sales distribution between male and female customers on a monthly basis. */

-- Aggregate total sales for each month and gender

WITH monthly_sales as (
   SELECT
        DATE_FORMAT(STR_TO_DATE(Date, '%d-%m-%Y'), '%Y-%m') as month,
        Gender,
        SUM(Total) as total_sales
    FROM walmartsales_dataset
    group by month, Gender
)

-- Select the monthly sales data for each gender

SELECT 
    month,
    Gender,
    total_sales
FROM monthly_sales
order by month, Gender;

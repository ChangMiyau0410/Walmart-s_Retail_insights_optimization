/* Task 4: Detecting Anomalies in Sales Transactions.
Walmart suspects that some transactions have unusually high or low sales compared to the average for the
product line. Identify these anomalies. */

-- Compare each transaction's total with the average total for its product line

SELECT 
    `Invoice ID`,
    `Product line`,
    Total,
    (SELECT avg(Total) FROM walmartsales_dataset AS w2 WHERE w2.`Product line` = w1.`Product line`) AS avg_total
FROM walmartsales_dataset AS w1
WHERE 
     -- Flag transactions with totals more than double the average
     
    Total > (SELECT avg(Total) FROM walmartsales_dataset AS w2 WHERE w2.`Product line` = w1.`Product line`) * 2
    or
    -- Or transactions with totals less than 1% of the average

    Total < (SELECT avg(Total) FROM walmartsales_dataset AS w2 WHERE w2.`Product line` = w1.`Product line`) * 0.01;


/* Task 7. Best Product Line by Customer Type.
Walmart wants to know which product lines are preferred by different customer types(Member vs. Normal). */

-- Calculate the number of purchases for each product line by customer type

WITH product_popularity as (
    SELECT 
        `Customer type`,
        `Product line`,
        count(*) as purchase_count
    FROM walmartsales_dataset
    group by `Customer type`, `Product line`
),

-- Rank the product lines based on the number of purchases for each customer type

ranked_products as (
    SELECT 
        *,
        rank() OVER (PARTITION BY `Customer type` order by purchase_count desc) as product_rank
    from product_popularity
)

-- Select the most preferred product line for each customer type

SELECT 
    `Customer type`,
    `Product line` AS most_preferred_product_line,
    purchase_count
FROM ranked_products
WHERE product_rank = 1
order by `Customer type`;

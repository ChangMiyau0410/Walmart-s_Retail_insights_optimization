/* Task 5. Most Popular Payment Method by City.
Walmart needs to determine the most popular payment method in each city to tailor marketing strategies. */

-- Count the number of transactions for each payment method by city
-- select * from walmartsales_dataset;

WITH payment_counts as (
    SELECT 
        City,
        Payment,
        COUNT(*) as payment_count
    FROM walmartsales_dataset
    group by City, Payment
),

-- Rank payment methods by transaction count for each city

ranked_payments as (
    SELECT 
        *,
        rank() OVER (partition by City order by payment_count desc) as payment_rank
    FROM payment_counts
)

-- Select the most popular payment method for each city

SELECT 
    City,
    Payment as most_popular_payment,
    payment_count
FROM ranked_payments
WHERE payment_rank = 1
order by City;

/* Task 10. Analyzing Sales Trends by Day of the Week.
Walmart wants to analyze the sales patterns to determine which day of the week
brings the highest sales. */

SELECT 
    DAYNAME(STR_TO_DATE(Date, '%d-%m-%Y')) as day_of_week,
    round(SUM(Total), 2) as total_sales
FROM walmartsales_dataset
group by  DAYNAME(STR_TO_DATE(Date, '%d-%m-%Y'))
order by total_sales desc;
